# Quiz Game

This is a simple quiz game built using Python and Tkinter library. It allows users to select a category and difficulty level, and then answer multiple-choice questions from the chosen category. The game tracks the user's score and provides feedback on correct and incorrect answers.

## Features

- Multiple categories: Choose from science, history, and geography categories.
- Three difficulty levels: Easy, medium, and hard.
- Randomly generated questions: Each game session includes 10 randomly selected questions.
- Timer: Users have one minute to complete the quiz. The game automatically ends when the time elapses.
- User feedback: Provides immediate feedback on correct and incorrect answers.
- Pass/Fail indication: Displays "Congratulations! You passed the quiz!" if the user's score is greater than 5, otherwise displays "Sorry, you failed the quiz."

## How to Play

Follow the on-screen instructions to play the game:

- Choose a category from the dropdown menu.
- Choose a difficulty level from the dropdown menu.
- Click the "Start" button to begin the quiz.
- Answer the multiple-choice questions by clicking on the options.
- Receive immediate feedback on correct and incorrect answers.
- The game ends automatically after one minute or when all questions are answered.
- View your final score and pass/fail indication.

## Dependencies

- Python 3.x
- Tkinter library (included in standard Python distribution)


## GROUP 4 MEMBERS
1.DADZIE KWESI ODARTEY -1820722
2.DANSO NICOLE KUSIWAA- 1821022
3.DARKO BENJAMIN - 1821122
4.DARKO KWAKU AGYEMANG -1821222
5.DAVESON JOSEPH -1821322
6.DEFIAT ZION SELORM - 1821422
7.DENTEH EDMUND KWAME - 1821522
8.DJANGMAH TETTEH PRINCE - 1821622
9.DOMEH FERDINAND COLLINS- 1821822
10.ESHUN PAPA KOJO AFOA - 1822022
11.BOTCHWAY ELAINE BOATEMAA - 1820422
12.COPSON WALLACE WALTER- 1820622
13.FRIMPONG OWUSU KELVIN- 1822122
14.GBADAGO BILL ETORNAM KWAME - 1822222
15.GWIRA REGINALD JOJO- 1822322
16.GYAMFI DARIUS OPOKU 1830522
17.GYASI JOSEPHINE AMA GYANEWAH- 1822522
18.EYRAM ADWOA DOVOH
19.HEVI ISAAC - 1822622